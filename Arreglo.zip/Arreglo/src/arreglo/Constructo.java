/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglo;

import java.util.Scanner;


    public class Constructo {
        
  
    Scanner cin = new Scanner(System.in);
    Scanner ci = new Scanner(System.in);
    Scanner c = new Scanner(System.in);
    String Marca;
    String Modelo;
    String Color;
    String Kilometraje;

    public Constructo(String Marca, String Modelo, String Color, String Kilometraje) {
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Color = Color;
        this.Kilometraje = Kilometraje;
    }

    public String getMarca() {
        return Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public String getColor() {
        return Color;
    }

    public String getKilometraje() {
        return Kilometraje;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setKilometraje(String Kilometraje) {
        this.Kilometraje = Kilometraje;
    }
    
    public void leen(){
        String ca;
        Double ce;
        int can;
       can= cin.nextInt();
       ca=ci.nextLine();
       ce=c.nextDouble();
       String [] Ma= new String [can];
       String [] Co= new String [can];
       Double [] Mo= new Double [can];
       Double [] Kil= new Double [can];
       System.out.println("---VENTA DE CARROS USADOS---");
       System.out.println("\nINGRESE LA CANTIDAD DE CARROS : ");
      
        for(int i=0; i<can; i++){
            cin.nextLine();
            System.out.println("INGRESE MARCA "+(i+1));
            Ma[i]= ci.nextLine();
            System.out.println("INGRESE MODELO "+(i+1));
            Mo[i]= c.nextDouble();
            System.out.println("INGRESE COLOR "+(i+1));
            Co[i]= ci.nextLine();
            System.out.println("INGRESE KILOMETRAJE "+(i+1));
            Kil[i]= c.nextDouble();
        } 
    }
    public void burbujak(double[]Kil){
        double ax;
        for(int i=0;i<(Kil.length-1);i++){
            for(int j=0;j<(Kil.length-1);j++){
                if(Kil[j]>Kil[j+1]){
                   ax = Kil[j];
                   Kil[j]=Kil[j+1];
                   Kil[j+1]= ax;
                }
            
        }
            
            
        }
        System.out.println("\nArreglo ordenado de forma creciente: ");
        for(int i=0;i<Kil.length;i++){
            System.out.println(Kil[i]+" - ");
        }
       
        
    }
     public void burbujam(double[]Mo){
         double aux;
        for(int i=0;i<(Mo.length-1);i++){
            for(int j=0;j<(Mo.length-1);j++){
                if(Mo[j]>Mo[j+1]){
                   aux = Mo[j];
                   Mo[j]=Mo[j+1];
                   Mo[j+1]= aux;
                }
            
        }
            
            
        }
        System.out.println("\nArreglo ordenado de forma creciente: ");
        for(int i=0;i<Mo.length;i++){
            System.out.println(Mo[i]+" - ");
        }
       
        
    }
    }   
